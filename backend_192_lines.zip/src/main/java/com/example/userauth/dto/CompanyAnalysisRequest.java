package com.example.userauth.dto;

import java.util.Map;

public class CompanyAnalysisRequest {

    private Long companyId;
    private Map<String, Object> yearMapping;
    private Map<String, Object> spreading;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Map<String, Object> getYearMapping() {
        return yearMapping;
    }

    public void setYearMapping(Map<String, Object> yearMapping) {
        this.yearMapping = yearMapping;
    }

    public Map<String, Object> getSpreading() {
        return spreading;
    }

    public void setSpreading(Map<String, Object> spreading) {
        this.spreading = spreading;
    }
}
