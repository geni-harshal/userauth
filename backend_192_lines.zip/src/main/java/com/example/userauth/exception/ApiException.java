package com.example.userauth.exception;

public class ApiException extends RuntimeException {
    public ApiException(String message) {
        super(message);
    }
}
