package com.example.userauth.service;

import com.example.userauth.dto.CompanyCreateRequest;
import com.example.userauth.dto.CompanyAnalysisRequest;
import com.example.userauth.entity.*;
import com.example.userauth.exception.ApiException;
import com.example.userauth.repository.CompanyRepository;
import com.example.userauth.repository.UserRepository;
import com.example.userauth.repository.FinancialSpreadingRepository;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
public class CompanyService {

    private final CompanyRepository companyRepository;
    private final UserRepository userRepository;
    private final FinancialSpreadingRepository financialSpreadingRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    public CompanyService(
            CompanyRepository companyRepository,
            UserRepository userRepository,
            FinancialSpreadingRepository financialSpreadingRepository
    ) {
        this.companyRepository = companyRepository;
        this.userRepository = userRepository;
        this.financialSpreadingRepository = financialSpreadingRepository;
    }

    /* =====================================================
       LIST – ONLY COMPANIES CREATED BY LOGGED-IN USER
       ===================================================== */
    public List<Company> listByUser(Long userId) {
        return companyRepository.findByCreatedBy_Id(userId);
    }

    /* =====================================================
       CREATE
       ===================================================== */
    @Transactional
    public Company createCompany(CompanyCreateRequest req, Long creatorUserId) {

        User creator = userRepository.findById(creatorUserId)
                .orElseThrow(() -> new ApiException("Creator user not found"));

        Company company = new Company();
        company.setCompanyName(req.getCompanyName());
        company.setCurrency(req.getCurrency());
        company.setBorrowerClassification(req.getBorrowerClassification());
        company.setDateOfAssessment(req.getDateOfAssessment());
        company.setRelationshipManager(req.getRelationshipManager());
        company.setIndustry(req.getIndustry());
        company.setCreatedBy(creator);

        /* -------- Owner Additional Support -------- */
        if (req.getOwnerAdditionalSupport() != null) {
            OwnerAdditionalSupport os = OwnerAdditionalSupport.builder()
                    .ownerPersonalNetWorth(
                            req.getOwnerAdditionalSupport().getOwnerPersonalNetWorth()
                    )
                    .build();
            company.setOwnerAdditionalSupport(os);
        }

        /* -------- Account Status -------- */
        if (req.getAccountStatus() != null) {
            CompanyCreateRequest.AccountStatusDTO as = req.getAccountStatus();
            AccountStatus acct = AccountStatus.builder()
                    .yearInBusiness(as.getYearInBusiness())
                    .locationOfBusiness(as.getLocationOfBusiness())
                    .relationshipAge(as.getRelationshipAge())
                    .auditorQuality(as.getAuditorQuality())
                    .auditorsOpinion(as.getAuditorsOpinion())
                    .nationalizationScheme(as.getNationalizationScheme())
                    .build();
            company.setAccountStatus(acct);
        }

        /* -------- Account Conduct -------- */
        if (req.getAccountConduct() != null) {
            CompanyCreateRequest.AccountConductDTO ac = req.getAccountConduct();
            AccountConduct conduct = AccountConduct.builder()
                    .bounceCheques(ac.getBounceCheques())
                    .ongoingCreditRelationship(ac.getOngoingCreditRelationship())
                    .delayInReceiptOfPrincipalProfitInstallments(
                            ac.getDelayInReceiptOfPrincipalProfitInstallments()
                    )
                    .numberOfDelinquencyInHistory(
                            ac.getNumberOfDelinquencyInHistory()
                    )
                    .writeOff(ac.getWriteOff())
                    .fraudAndLitigationIncidences(
                            ac.getFraudAndLitigationIncidences()
                    )
                    .build();
            company.setAccountConduct(conduct);
        }

        Company saved = companyRepository.save(company);
        saved.setBorrowerId(String.format("BRW%06d", saved.getId()));

        return companyRepository.save(saved);
    }

    /* =====================================================
       FIND BY ID
       ===================================================== */
    public Optional<Company> findById(Long id) {
        return companyRepository.findById(id);
    }

    /* =====================================================
       FIND BY ID + USER
       ===================================================== */
    public Optional<Company> findByIdAndUser(Long id, Long userId) {
        return companyRepository.findByIdAndCreatedBy_Id(id, userId);
    }

    /* =====================================================
       DELETE
       ===================================================== */
    @Transactional
    public void deleteById(Long id) {
        Company company = companyRepository.findById(id)
                .orElseThrow(() -> new ApiException("Company not found"));
        companyRepository.delete(company);
    }

    /* =====================================================
       DELETE BY USER
       ===================================================== */
    @Transactional
    public void deleteByIdAndUser(Long id, Long userId) {
        Company company = companyRepository
                .findByIdAndCreatedBy_Id(id, userId)
                .orElseThrow(() ->
                        new ApiException("Company not found or access denied"));

        companyRepository.delete(company);
    }

    /* =====================================================
       🔥 SAVE NORMALIZED FINANCIAL SPREADING
       ===================================================== */
    @Transactional
    public FinancialSpreading saveNormalizedSpreading(
            Long companyId,
            Long userId,
            CompanyAnalysisRequest request
    ) {

        Company company = companyRepository
                .findByIdAndCreatedBy_Id(companyId, userId)
                .orElseThrow(() ->
                        new ApiException("Company not found or access denied"));

        FinancialSpreading spreading = FinancialSpreading.builder()
                .company(company)
                .createdBy(userRepository.findById(userId).orElse(null))
                .build();

        /* ---------- YEAR MAPPING ---------- */
        Map<String, Object> rawYearMapping =
                request.getYearMapping() == null
                        ? Collections.emptyMap()
                        : request.getYearMapping();

        Map<String, Integer> labelToYearNumber = new HashMap<>();

        for (Map.Entry<String, Object> e : rawYearMapping.entrySet()) {
            String label = e.getKey();
            Integer yearNumber = null;

            try {
                if (e.getValue() != null) {
                    yearNumber = Integer.parseInt(String.valueOf(e.getValue()));
                }
            } catch (Exception ignored) {}

            SpreadingYear sy = SpreadingYear.builder()
                    .label(label)
                    .yearNumber(yearNumber)
                    .spreading(spreading)
                    .build();

            spreading.getYears().add(sy);

            if (yearNumber != null) {
                labelToYearNumber.put(label, yearNumber);
            }
        }

        /* ---------- SPREADING ---------- */
        Map<String, Object> rawSpreading =
                request.getSpreading() == null
                        ? Collections.emptyMap()
                        : request.getSpreading();

        for (Map.Entry<String, Object> catEntry : rawSpreading.entrySet()) {

            if (!(catEntry.getValue() instanceof Map)) continue;

            SpreadingCategory category = SpreadingCategory.builder()
                    .name(catEntry.getKey())
                    .spreading(spreading)
                    .build();

            Map<String, Object> items =
                    (Map<String, Object>) catEntry.getValue();

            for (Map.Entry<String, Object> itemEntry : items.entrySet()) {

                SpreadingItem item = SpreadingItem.builder()
                        .name(itemEntry.getKey())
                        .category(category)
                        .build();

                if (itemEntry.getValue() instanceof Map) {
                    Map<String, Object> yearValues =
                            (Map<String, Object>) itemEntry.getValue();

                    for (Map.Entry<String, Object> yv : yearValues.entrySet()) {

                        String yearLabel = yv.getKey();
                        Integer yearNumber = labelToYearNumber.get(yearLabel);

                        if (yearNumber == null) {
                            try {
                                yearNumber = Integer.parseInt(yearLabel);
                            } catch (Exception ignored) {}
                        }

                        BigDecimal value = null;
                        try {
                            if (yv.getValue() != null) {
                                value = new BigDecimal(
                                        String.valueOf(yv.getValue()).trim()
                                );
                            }
                        } catch (Exception ignored) {}

                        SpreadingValue val = SpreadingValue.builder()
                                .yearLabel(yearLabel)
                                .yearNumber(yearNumber)
                                .value(value)
                                .item(item)
                                .build();

                        item.getValues().add(val);
                    }
                }

                category.getItems().add(item);
            }

            spreading.getCategories().add(category);
        }

        return financialSpreadingRepository.save(spreading);
    }
}
