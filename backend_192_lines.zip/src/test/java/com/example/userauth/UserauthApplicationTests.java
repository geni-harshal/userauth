package com.example.userauth;

import org.junit.jupiter.api.Test;

class UserauthApplicationTests {

    @Test
    void contextLoads() {
        // disabled for now
    }
}
